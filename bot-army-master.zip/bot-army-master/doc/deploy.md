# How to Deploy your Bot to Heroku

